package net.dy.server.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * ���񣺲���ĳ����
 */
@WebServlet("/searchRecipe.action")
public class SearchRecipeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchRecipeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ������Ա�Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");
		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		} else {
			writer.write("<h1>��ҳ��Ϊ�������׽��</h1>");
			writer.write("<a href='recipe.action'>������ز��׹�������</a>");
			String searchRecipe = request.getParameter("searchRecipe");
			// ��ȡ�û���Ϣ
			try {
				if ("".equals(searchRecipe)) {
					writer.write("<h1>δ�ҵ������Ϣ</h1>");
				} else {
					RecipeService recipeService = new RecipeService();
					List<Recipe> recipes = recipeService.getSpecificRecipes(searchRecipe);
					if (recipes.size() == 0) {
						writer.write("<h1>δ�ҵ������Ϣ</h1>");
					} else {
						String root = getServletContext().getRealPath("/");
						writer.write("<br/><br/>");
						writer.write("<table border='1' cellspacing='0'>");
						writer.write("<tr align='center'>");
						writer.write("<th width='80'>��������</th>");
						writer.write("<th width='80'>��������</th>");
						writer.write("<th width='60'>����ͼƬ</th>");
						writer.write("<th width='100'>����ԭ����</th>");
						writer.write("<th width='100'>���ײ�������</th>");
						writer.write("<th width='50'>����</th>");
						writer.write("<th width='50'>����</th>");
						writer.write("<th width='50'>����</th>");
						writer.write("</tr>");
						for (Recipe recipe : recipes) {
							writer.write("<tr align='center'>");
							// ��ӡ��������
							writer.write("<td>");
							writer.write(recipe.getRecipeName() + "<br/><a href='recipeShow.action?recipeName="
									+ recipe.getRecipeName() + "'>�鿴����</a>");
							writer.write("</td>");
							// ��ӡ��������
							writer.write("<td>");
							writer.write(recipe.getReciptType());
							writer.write("</td>");
							// ��ӡ����ͼƬ
							writer.write("<td>");
							if ("".equals(recipe.getRecipePhotoPath())) {
								writer.write("������ͼƬ");
							} else {
								writer.write("<img src='" + root + recipe.getRecipePhotoPath()
										+ "' width='80' height='80' />");
							}
							writer.write("</td>");
							// ��ӡ����ԭ����
							writer.write("<td>");
							writer.write(recipe.getRecipeMaterial());
							writer.write("</td>");
							// ��ӡ���ײ���
							writer.write("<td>");
							writer.write(recipe.getRecipeSteps());
							writer.write("</td>");
							// ��ӡ�鿴���۲���
							writer.write("<td>");
							writer.write("<a href='comment.action?recipeName=" + recipe.getRecipeName() + "'>�鿴</a>");
							writer.write("</td>");
							// ��ӡ�޸Ĳ���
							writer.write("<td>");
							writer.write(
									"<a href='updateRecipe.action?recipeName=" + recipe.getRecipeName() + "'>�޸�</a>");
							writer.write("</td>");
							// ��ӡɾ������
							writer.write("<td>");
							writer.write(
									"<a href='deleteRecipe.action?recipeName=" + recipe.getRecipeName() + "'>ɾ��</a>");
							writer.write("</td>");
							writer.write("</tr>");
						}
						writer.write("</table>");
					}
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
