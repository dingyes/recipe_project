package net.dy.server.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * Servlet implementation class RecipeDetailsDisplayServlet
 */
@WebServlet("/recipeShow.action")
public class RecipeDetailsDisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RecipeDetailsDisplayServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String recipeName = request.getParameter("recipeName");
		System.out.println(recipeName + "");
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ������Ա�Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");
		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		} else {
			writer.write("<h1>'" + recipeName + "'����չʾ</h1>");
			writer.write("<a href='recipe.action'>������ز��׹�������</a>");
			try {
				RecipeService recipeService = new RecipeService();
				List<Recipe> recipes = recipeService.getRecipes("select * from recipeinfo");
				String root = getServletContext().getRealPath("/");
				writer.write("<br/><br/>");
				writer.write("<table border='1' cellspacing='0'>");
				writer.write("<tr align='center'>");
				writer.write("<th width='80'>��������</th>");
				writer.write("<th width='80'>��������</th>");
				writer.write("<th width='100'>����ͼƬ</th>");
				writer.write("<th width='100'>����ԭ����</th>");
				writer.write("<th width='100'>���ײ�������</th>");
				writer.write("<th width='80'>������</th>");
				writer.write("</tr>");
				for (Recipe recipe : recipes) {
					if (recipe.getRecipeName().equals(recipeName)) {
						writer.write("<tr align='center'>");
						// ��ӡ��������
						writer.write("<td>");
						writer.write(recipe.getRecipeName());
						writer.write("</td>");
						// ��ӡ��������
						writer.write("<td>");
						writer.write(recipe.getReciptType());
						writer.write("</td>");
						// ��ӡ����ͼƬ
						writer.write("<td>");
						if ("".equals(recipe.getRecipePhotoPath())) {
							writer.write("������ͼƬ");
						} else {
							writer.write(
									"<img src='" + root + recipe.getRecipePhotoPath() + "' width='80' height='80' />");
						}
						writer.write("</td>");
						// ��ӡ����ԭ����
						writer.write("<td>");
						writer.write(recipe.getRecipeMaterial());
						writer.write("</td>");
						// ��ӡ���ײ���
						writer.write("<td>");
						writer.write(recipe.getRecipeSteps());
						writer.write("</td>");
						// ��ӡ���׵�����
						writer.write("<td>");
						writer.write(recipe.getRecipeLikeNum() + "");
						writer.write("</td>");
						writer.write("</tr>");
						break;
					}
				}
				writer.write("</table>");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
