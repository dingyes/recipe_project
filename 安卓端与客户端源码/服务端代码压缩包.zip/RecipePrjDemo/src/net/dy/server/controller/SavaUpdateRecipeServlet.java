package net.dy.server.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * ���񣺱���Բ˵����޸�
 */
@WebServlet("/saveUpdateRecipe.action")
public class SavaUpdateRecipeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SavaUpdateRecipeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// ��ȡ�޸���Ϣ
		String recipeName = request.getParameter("recipeName");
		String recipeType = request.getParameter("recipeType");
		String recipeMaterial = request.getParameter("recipeMaterial");
		String recipeSteps = request.getParameter("recipeSteps");
		String recipePhotoPath = request.getParameter("recipePhotoPath");
		int recipeLikeNum = Integer.parseInt(request.getParameter("recipeLikeNum"));
		if (!"".equals(recipePhotoPath)) {
			String root = getServletContext().getRealPath("/");
			File file = new File(root + recipePhotoPath);
			if (file.exists()) {
				// ���������Ϣ
				Recipe recipe = new Recipe(recipeName, recipeType, recipePhotoPath, recipeMaterial, recipeSteps,
						recipeLikeNum);
				try {
					boolean flag = new RecipeService().updateRecipe(recipe);
					if (flag) {
						System.out.println("�����޸ĳɹ�");
						response.sendRedirect("recipe.action");
					} else {
						System.out.println("�����޸�ʧ�ܣ��������޸�");
						response.sendRedirect("recipe.action");
					}
				} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("����ͼƬ·�������ڣ��������޸�");
				response.sendRedirect("recipe.action");
			}
		} else {
			// ���������Ϣ
			Recipe recipe = new Recipe(recipeName, recipeType, recipePhotoPath, recipeMaterial, recipeSteps,
					recipeLikeNum);
			try {
				boolean flag = new RecipeService().updateRecipe(recipe);
				if (flag) {
					System.out.println("�����޸ĳɹ�");
					response.sendRedirect("recipe.action");
				} else {
					System.out.println("�����޸�ʧ�ܣ��������޸�");
					response.sendRedirect("recipe.action");
				}
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
