package net.dy.server.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * ���񣺲���ĳ���׵�������
 */
@WebServlet("/searchLikeInfo.action")
public class SearchLikeInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchLikeInfoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ������Ա�Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");
		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		} else {
			writer.write("<h1>��ҳ��Ϊ�������</h1>");
			writer.write("<a href='like.action'>��������û���������</a>");
			String searchLikeInfo = request.getParameter("searchLikeInfo");
			// ��ȡ�û���Ϣ
			try {
				if ("".equals(searchLikeInfo)) {
					writer.write("<h1>δ�ҵ������Ϣ</h1>");
				} else {
					RecipeService recipeService = new RecipeService();
					List<Recipe> recipes = recipeService.getSpecificRecipes(searchLikeInfo);
					if (recipes.size() == 0) {
						writer.write("<h1>δ�ҵ������Ϣ</h1>");
					} else {
						// �û���������
						writer.write("<br/><br/>");
						writer.write("<table border='1' cellspacing='0'>");
						writer.write("<tr align='center'>");
						writer.write("<th width='100'>��������</th>");
						writer.write("<th width='100'>���׵�����</th>");
						writer.write("</tr>");
						for (Recipe recipe : recipes) {
							writer.write("<tr align='center'>");
							// ��ӡ��������
							writer.write("<td>");
							writer.write(recipe.getRecipeName());
							writer.write("</td>");
							// ��ӡ���׵�����
							writer.write("<td>");
							writer.write(recipe.getRecipeLikeNum() + "");
							writer.write("</td>");
							writer.write("</tr>");
						}
						writer.write("</table>");
					}
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
