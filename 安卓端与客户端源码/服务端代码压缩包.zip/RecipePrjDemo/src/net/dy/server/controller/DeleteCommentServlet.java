package net.dy.server.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.service.CommentService;

/**
 * ����ɾ�����ۣ����������۹���
 */
@WebServlet("/deleteComment.action")
public class DeleteCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteCommentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ������Ա�Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");
		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		} else {
			// ��ȡ������Ϣ
			String commentRecipe = request.getParameter("commentRecipe");
			String commentNumber = request.getParameter("commentNumber");
			String commentInfo = request.getParameter("commentInfo");
			// ɾ��
			try {
				boolean flag = new CommentService().deleteComment(commentRecipe, commentNumber, commentInfo);
				if (flag) {
					System.out.println("����ɾ���ɹ�");
					response.sendRedirect("comment.action");
				} else {
					System.out.println("����ɾ��ʧ��");
					response.sendRedirect("comment.action");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
