package net.dy.server.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.User;
import net.dy.service.UserService;

/**
 * ���������û�������ʾ�ڴ�ҳ��
 */
@WebServlet("/searchUser.action")
public class SearchUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ������Ա�Ƿ��Ѿ���¼
		ServletContext context = getServletContext();
		Object administrator = context.getAttribute("administrator");
		if (null == administrator) {// ��δ��¼
			writer.write("����δ��¼��<a href='login.html'>������µ�¼</a>");
		} else {
			writer.write("<h1>��ҳ��Ϊ�����û����</h1>");
			writer.write("<a href='user.action'>��������û���������</a>");
			String searchUser = request.getParameter("searchUser");
			// ��ȡ�û���Ϣ
			try {
				if ("".equals(searchUser)) {
					writer.write("<h1>δ�ҵ������Ϣ</h1>");
				} else {
					UserService userService = new UserService();
					List<User> users = userService.getSpecificUsers(searchUser);
					if (users.size() == 0) {
						writer.write("<h1>δ�ҵ������Ϣ</h1>");
					} else {
						// �û���������
						writer.write("<br/><br/>");
						writer.write("<table border='1' cellspacing='0'>");
						writer.write("<tr align='center'>");
						writer.write("<th width='120'>�û��绰����</th>");
						writer.write("<th width='100'>�û��ǳ�</th>");
						writer.write("<th width='100'>�û��Ա�</th>");
						writer.write("<th width='80'>����</th>");
						writer.write("</tr>");
						for (User user : users) {
							writer.write("<tr align='center'>");
							// ��ӡ�û��绰����
							writer.write("<td>");
							writer.write(user.getUserNumber());
							writer.write("</td>");
							// ��ӡ�û��ǳ�
							writer.write("<td>");
							writer.write(user.getUserName());
							writer.write("</td>");
							// ��ӡ�û��Ա�
							writer.write("<td>");
							writer.write(user.getUserSex());
							writer.write("</td>");
							// ��ӡɾ������
							writer.write("<td>");
							writer.write("<a href='deleteUser.action?userNumber=" + user.getUserNumber() + "'>ɾ��</a>");
							writer.write("</td>");
							writer.write("</tr>");
						}
						writer.write("</table>");
					}
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
