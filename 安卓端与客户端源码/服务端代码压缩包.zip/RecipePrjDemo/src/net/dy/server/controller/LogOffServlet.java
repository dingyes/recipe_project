package net.dy.server.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ����ע����¼
 */
@WebServlet("/logoff.action")
public class LogOffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LogOffServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ��ȡContext����
		ServletContext context = this.getServletContext();
		// ��ȡPrintWriter����
		PrintWriter writer = response.getWriter();
		// ��ʾһ�£�ע���ɹ�
		String uName = (String) context.getAttribute("administrator");
		writer.write(uName + "ע���ɹ�");
		context.removeAttribute("administrator");
		// ��ʾһ�£�����ͳ�����
		writer.write("<br/><br/>");
		writer.write("<a href='login.html'>�˽����½����</a>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
