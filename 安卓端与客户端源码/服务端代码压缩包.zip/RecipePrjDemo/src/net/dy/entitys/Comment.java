package net.dy.entitys;

public class Comment {
	private String commentRecipe;  // ���۵Ĳ�������
	private String commentNumber;  // ���۵��û�����
	private String commentInfo;    // ���۵�����

	public Comment() {
		
	}

	public Comment(String commentRecipe, String commentNumber, String commentInfo) {
		super();
		this.commentRecipe = commentRecipe;
		this.commentNumber = commentNumber;
		this.commentInfo = commentInfo;
	}

	public String getCommentRecipe() {
		return commentRecipe;
	}

	public void setCommentRecipe(String commentRecipe) {
		this.commentRecipe = commentRecipe;
	}

	public String getCommentNumber() {
		return commentNumber;
	}

	public void setCommentNumber(String commentNumber) {
		this.commentNumber = commentNumber;
	}

	public String getCommentInfo() {
		return commentInfo;
	}

	public void setCommentInfo(String commentInfo) {
		this.commentInfo = commentInfo;
	}

}
