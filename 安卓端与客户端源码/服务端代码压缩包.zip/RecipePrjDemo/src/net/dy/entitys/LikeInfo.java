package net.dy.entitys;

public class LikeInfo {
	private String likeRecipe;  // ���޵Ĳ���
	private String likeNumber;  // ���޵��û��ĺ���

	public LikeInfo() {

	}

	public LikeInfo(String likeRecipe, String likeNumber) {
		super();
		this.likeRecipe = likeRecipe;
		this.likeNumber = likeNumber;
	}

	public String getLikeRecipe() {
		return likeRecipe;
	}

	public void setLikeRecipe(String likeRecipe) {
		this.likeRecipe = likeRecipe;
	}

	public String getLikeNumber() {
		return likeNumber;
	}

	public void setLikeNumber(String likeNumber) {
		this.likeNumber = likeNumber;
	}

}
