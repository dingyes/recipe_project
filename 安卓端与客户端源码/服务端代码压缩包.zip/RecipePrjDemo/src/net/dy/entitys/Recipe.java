package net.dy.entitys;

public class Recipe {
	private String recipeName;   // ��������
	private String reciptType;   // ��������
	private String recipePhotoPath;  // ��Ų���ͼƬ·��
	private String recipeMaterial;   // ����ԭ����
	private String recipeSteps;  // ���ײ���
	private int recipeLikeNum;   // ���׵�������


	public Recipe() {

	}
	
	public Recipe(String recipeName, String reciptType, String recipePhotoPath, String recipeMaterial,
			String recipeSteps, int recipeLikeNum) {
		super();
		this.recipeName = recipeName;
		this.reciptType = reciptType;
		this.recipePhotoPath = recipePhotoPath;
		this.recipeMaterial = recipeMaterial;
		this.recipeSteps = recipeSteps;
		this.recipeLikeNum = recipeLikeNum;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public String getReciptType() {
		return reciptType;
	}

	public void setReciptType(String reciptType) {
		this.reciptType = reciptType;
	}

	public String getRecipePhotoPath() {
		return recipePhotoPath;
	}

	public void setRecipePhotoPath(String recipePhotoPath) {
		this.recipePhotoPath = recipePhotoPath;
	}

	public String getRecipeMaterial() {
		return recipeMaterial;
	}

	public void setRecipeMaterial(String recipeMaterial) {
		this.recipeMaterial = recipeMaterial;
	}

	public String getRecipeSteps() {
		return recipeSteps;
	}

	public void setRecipeSteps(String recipeSteps) {
		this.recipeSteps = recipeSteps;
	}

	public int getRecipeLikeNum() {
		return recipeLikeNum;
	}

	public void setRecipeLikeNum(int recipeLikeNum) {
		this.recipeLikeNum = recipeLikeNum;
	}

}
