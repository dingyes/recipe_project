package net.dy.android.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.User;
import net.dy.service.UserService;

/**
 * �û�ע��ӿ�
 */
@WebServlet("/register")
public class RegisterVerificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterVerificationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		boolean flag1 = true;
		String tip = null;
		// ��ȡ�ͻ��˷��͵�����
		String phone = request.getParameter("phone");
		String password = request.getParameter("password");
		String sex = request.getParameter("sex");
		String name = request.getParameter("name");
		try {
			UserService userService = new UserService();
			List<User> users = userService.getUsers("select * from userinfo");
			for (User user : users) {
				if (user.getUserNumber().equals(phone)) {
					tip = "�Ѵ��ڸ��û�������������";
					flag1 = false;
					writer.write(flag1 + "&&&" + tip);
					break;
				}
			}
			if (flag1) {
				User user = new User();
				user.setUserNumber(phone);
				user.setUserPassword(password);
				user.setUserSex(sex);
				user.setUserName(name);
				boolean flag = userService.regestUser(user);
				if (flag) {
					tip = "ע��ɹ�";
					writer.write(flag + "&&&" + tip);
				} else {
					tip = "ע��ʧ��";
					writer.write(flag + "&&&" + tip);
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
