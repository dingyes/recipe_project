package net.dy.android.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * ��ȡ���׵������нӿ�
 */
@WebServlet("/rank")
public class GetRankServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetRankServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String line = "&&&";
			RecipeService recipeService = new RecipeService();
			List<Recipe> recipes = recipeService.getRecipes("select * from recipeinfo order by recipe_likenum desc");
			for (Recipe recipe : recipes) {
				line = line + recipe.getRecipeName() + "&" + recipe.getReciptType() + "&" + recipe.getRecipeLikeNum()
						+ "&&&";
			}
			PrintWriter writer = response.getWriter();
			writer.write(line);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
