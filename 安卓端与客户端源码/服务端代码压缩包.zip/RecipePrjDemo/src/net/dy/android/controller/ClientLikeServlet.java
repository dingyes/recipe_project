package net.dy.android.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.LikeInfo;
import net.dy.service.LikeInfoService;
import net.dy.service.RecipeService;

/**
 * ��ȡ�û��Բ��׵ĵ�����Ϣ�ӿڣ��жϺ�д�����ݿ�
 */
@WebServlet("/like")
public class ClientLikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ClientLikeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String likeRecipe = request.getParameter("likeRecipe");
		String likeUser = request.getParameter("LikeUser");
		try {
			LikeInfoService likeInfoService = new LikeInfoService();
			if (likeInfoService.isExistLikeInfo(likeRecipe, likeUser)) {
				writer.write("false&&&�����޹��ò���");
			} else {
				LikeInfo likeInfo = new LikeInfo(likeRecipe, likeUser);
				boolean flag = new LikeInfoService().addLikeInfo(likeInfo);
				if (flag) {
					boolean flag1 = new RecipeService().addLikeNumber(likeRecipe);
					if (flag1) {
						writer.write(flag1 + "&&&���޳ɹ�");
					} else {
						writer.write(flag1 + "&&&����ʧ��");
					}
				} else {
					writer.write(flag + "&&&����ʧ��");
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
