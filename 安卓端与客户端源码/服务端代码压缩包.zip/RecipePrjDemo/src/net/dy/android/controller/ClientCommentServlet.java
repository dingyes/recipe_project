package net.dy.android.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Comment;
import net.dy.service.CommentService;

/**
 * ��ȡ�û��Բ��׵�������Ϣ�ӿڣ��жϺ�д�����ݿ�
 */
@WebServlet("/comment")
public class ClientCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ClientCommentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String commentRecipe = request.getParameter("commentRecipe");
		String commentUser = request.getParameter("commentUser");
		String commentInfo = request.getParameter("commentInfo");
		Comment comment = new Comment(commentRecipe, commentUser, commentInfo);
		PrintWriter writer = response.getWriter();
		try {
			boolean flag1 = new CommentService().isExistComment(comment);
			if (!flag1) {
				boolean flag = new CommentService().addComment(comment);
				if (flag) {
					writer.write(flag + "&&&���۳ɹ�");
				} else {
					writer.write(flag + "&&&����ʧ��");
				}
			} else {
				writer.write("false&&&�����д�����");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
