package net.dy.android.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * ��ȡĳ����ͼƬ�ӿ�
 */
@WebServlet("/recipeImg")
public class GetSpecificRecipeImgServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetSpecificRecipeImgServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String recipeName = request.getParameter("recipeName");
		String root = getServletContext().getRealPath("/");
		OutputStream out = response.getOutputStream();
		try {
			RecipeService recipeService = new RecipeService();
			List<Recipe> recipes = recipeService.getRecipes("select * from recipeinfo");
			for (Recipe recipe : recipes) {
				if (recipe.getRecipeName().equals(recipeName)) {
					String path = recipe.getRecipePhotoPath();
					int n = -1;
					if ("".equals(path)) {
						InputStream in = new FileInputStream(root + "images\\recipeImgs\\default\\default.jpg");
						while ((n = in.read()) != -1) {
							out.write(n);
						}
						in.close();
						out.close();
					} else {
						InputStream in = new FileInputStream(root + path);
						while ((n = in.read()) != -1) {
							out.write(n);
						}
						in.close();
						out.close();
					}
					break;
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
