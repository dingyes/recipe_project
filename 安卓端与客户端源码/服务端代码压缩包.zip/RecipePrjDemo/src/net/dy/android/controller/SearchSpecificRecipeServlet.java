package net.dy.android.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.dy.entitys.Recipe;
import net.dy.service.RecipeService;

/**
 * ���������ӿ�
 */
@WebServlet("/searchRecipe")
public class SearchSpecificRecipeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchSpecificRecipeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String information = request.getParameter("information");
		try {
			String line;
			if (!"".equals(information)) {
				line = "true&&&";
				RecipeService recipeService = new RecipeService();
				List<Recipe> recipes = recipeService.getSpecificRecipes(information);
				if (recipes.size() > 0) {
					for (Recipe recipe : recipes) {
						line = line + recipe.getRecipeName() + "&" + recipe.getReciptType() + "&"
								+ recipe.getRecipeLikeNum() + "&&&";
					}
				} else {
					line = "false&&&";
				}
			} else {
				line = "false&&&";
			}
			writer.write(line);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
