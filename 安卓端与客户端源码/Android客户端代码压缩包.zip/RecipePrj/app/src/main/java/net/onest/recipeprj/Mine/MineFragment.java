package net.onest.recipeprj.Mine;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import net.onest.recipeprj.Class.User;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MineFragment extends Fragment {
    private final int REQUEST = 100;
    private View root;
    private ImageView userPhoto;
    private TextView userName;
    private TextView userNumber;
    private TextView myLikes;
    private TextView myComments;
    private TextView updateInfo;
    private TextView updatePhoto;
    private TextView hobby;
    private TextView sex;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] messages = str.split("&&&");
                    userName.setText(messages[0]);
                    userNumber.setText(messages[1]);
                    User.setUserNumberLogin(messages[1]);
                    sex.setText(messages[2]);
                    hobby.setText(messages[3]);
                    break;
                case 2://表示接收服务端的图片
                    Bitmap rawBitmap = (Bitmap) msg.obj;
                    //把图片显示在图片控件中
                    Bitmap bitmap = ConfigUtil.zoomBitmap(rawBitmap, 95, 95);
                    userPhoto.setImageBitmap(bitmap);
                    break;
            }
        }
    };


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_mine, container, false);
        findViews();
        if (null != User.getUserNumberLogin()) {
            showNumberLogin(ConfigUtil.SERVER_ADDR + "personal?phone=" + User.getUserNumberLogin());
            showPhotoLogin(ConfigUtil.SERVER_ADDR + "personalImg?phone=" + User.getUserNumberLogin());
        }
        setListeners();
        return root;
    }

    private void findViews() {
        userName = root.findViewById(R.id.user_name);
        userNumber = root.findViewById(R.id.user_phone);
        userPhoto = root.findViewById(R.id.user_photo);
        myComments = root.findViewById(R.id.my_comments);
        myLikes = root.findViewById(R.id.my_likes);
        updateInfo = root.findViewById(R.id.update_info);
        updatePhoto = root.findViewById(R.id.update_photo);
        hobby = root.findViewById(R.id.hobby);
        sex = root.findViewById(R.id.sex);
    }

    private void setListeners() {
        MineFragment.MyClickListener listener = new MineFragment.MyClickListener();
        userNumber.setOnClickListener(listener);
        updatePhoto.setOnClickListener(listener);
        updateInfo.setOnClickListener(listener);
        myLikes.setOnClickListener(listener);
        myComments.setOnClickListener(listener);
    }

    private void showPhotoLogin(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    //获取字节输入流
                    InputStream in = conn.getInputStream();
                    //把输入流解析成一个Bitmap对象
                    Bitmap bitmap = BitmapFactory.decodeStream(in);
                    in.close();
                    //借助于Message，将图片显示在界面上
                    Message msg = new Message();
                    msg.what = 2;
                    msg.obj = bitmap;
                    handler.sendMessage(msg);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void showNumberLogin(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    /**
     * 内部类方式自定义点击事件监听器
     */
    private class MyClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.user_phone:
                    Intent intent = new Intent();
                    intent.setClass(getContext(), LoginActivity.class);
                    startActivityForResult(intent, REQUEST);
                    break;
                case R.id.my_comments:
                    if (!"点此登录".equals(userNumber.getText().toString())) {
                        Intent intent2 = new Intent();
                        intent2.setClass(getContext(), GetCommentActivity.class);
                        intent2.putExtra("phone", userNumber.getText().toString());
                        startActivity(intent2);
                    } else {
                        Toast.makeText(getContext(), "您还没有登陆，请先登录", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.my_likes:
                    if (!"点此登录".equals(userNumber.getText().toString())) {
                        Intent intent3 = new Intent();
                        intent3.setClass(getContext(), GetLikeInfoActivity.class);
                        intent3.putExtra("phone", userNumber.getText().toString());
                        startActivity(intent3);
                    } else {
                        Toast.makeText(getContext(), "您还没有登陆，请先登录", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.update_info:
                    if (!"点此登录".equals(userNumber.getText().toString())) {
                        Intent intent4 = new Intent();
                        intent4.setClass(getContext(), UpdateInfoActivity.class);
                        intent4.putExtra("userName", userName.getText().toString());
                        intent4.putExtra("phone", userNumber.getText().toString());
                        intent4.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivityForResult(intent4, REQUEST);
                    } else {
                        Toast.makeText(getContext(), "您还没有登陆，请先登录", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.update_photo:
                    if (!"点此登录".equals(userNumber.getText().toString())) {
                        Intent intent5 = new Intent();
                        intent5.setClass(getContext(), UpdateImgActivity.class);
                        intent5.putExtra("phone", userNumber.getText().toString());
                        intent5.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivityForResult(intent5, REQUEST);
                    } else {
                        Toast.makeText(getContext(), "您还没有登陆，请先登录", Toast.LENGTH_SHORT).show();
                    }
                    break;

            }
        }
    }

    // 接收返回的响应数据，并刷新界面
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 对登陆的相应
        if (requestCode == REQUEST && resultCode == 200) {
            final String phoneNumber = data.getStringExtra("phone");
            userNumber.setText(phoneNumber);
            showNumberLogin(ConfigUtil.SERVER_ADDR + "personal?phone=" + phoneNumber);
            showPhotoLogin(ConfigUtil.SERVER_ADDR + "personalImg?phone=" + phoneNumber);
        } else if (requestCode == REQUEST && resultCode == 300) {
            final String phoneNumber = data.getStringExtra("phone");
            userNumber.setText(phoneNumber);
            showNumberLogin(ConfigUtil.SERVER_ADDR + "personal?phone=" + phoneNumber);
            showPhotoLogin(ConfigUtil.SERVER_ADDR + "personalImg?phone=" + phoneNumber);
        } else if (requestCode == REQUEST && resultCode == 400) {
            final String phoneNumber = data.getStringExtra("phone");
            userNumber.setText(phoneNumber);
            showNumberLogin(ConfigUtil.SERVER_ADDR + "personal?phone=" + phoneNumber);
            showPhotoLogin(ConfigUtil.SERVER_ADDR + "personalImg?phone=" + phoneNumber);
        }

    }

}
