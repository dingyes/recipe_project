package net.onest.recipeprj.Class;

public class LikeInfo {
    private String likeRecipe;  // 点赞的菜谱
    private String likeNumber;  // 点赞的用户的号码

    public LikeInfo() {

    }

    public LikeInfo(String likeRecipe, String likeNumber) {
        super();
        this.likeRecipe = likeRecipe;
        this.likeNumber = likeNumber;
    }

    public String getLikeRecipe() {
        return likeRecipe;
    }

    public void setLikeRecipe(String likeRecipe) {
        this.likeRecipe = likeRecipe;
    }

    public String getLikeNumber() {
        return likeNumber;
    }

    public void setLikeNumber(String likeNumber) {
        this.likeNumber = likeNumber;
    }
}
