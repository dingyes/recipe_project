package net.onest.recipeprj.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import net.onest.recipeprj.Class.Comment;
import net.onest.recipeprj.Mine.GetCommentActivity;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class CommentAdapter extends BaseAdapter {
    private Context commentContext;
    private List<Comment> comments = new ArrayList<>();
    private int itemLayoutRes;
    private String phone;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    if ("true".equals(str)) {
                        Toast.makeText(commentContext, "删除成功", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent();
                        intent.setClass(commentContext, GetCommentActivity.class);
                        intent.putExtra("phone", phone);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        commentContext.startActivity(intent);
                    } else {
                        Toast.makeText(commentContext, "删除失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    };

    public CommentAdapter(Context commentContext, List<Comment> comments, int itemLayoutRes) {
        this.commentContext = commentContext;
        this.comments = comments;
        this.itemLayoutRes = itemLayoutRes;
    }

    @Override
    public int getCount() {
        if (null != comments) {
            return comments.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (null != comments) {
            return comments.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(commentContext);
        convertView = inflater.inflate(itemLayoutRes, null);
        // 获取控件引用
        TextView recipe = convertView.findViewById(R.id.comment_recipe);
        TextView info = convertView.findViewById(R.id.comment_info);
        final TextView delete = convertView.findViewById(R.id.comment_delete);

        recipe.setText(comments.get(position).getCommentRecipe());
        info.setText(comments.get(position).getCommentInfo());
        phone = comments.get(position).getCommentNumber();

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        try {
                            String commentRecipe = comments.get(position).getCommentRecipe();
                            String commentInfo = comments.get(position).getCommentInfo();
                            String commentPhone = comments.get(position).getCommentNumber();
                            URL url = new URL(ConfigUtil.SERVER_ADDR + "delComment?phone=" + commentPhone + "&recipe=" + commentRecipe + "&info=" + commentInfo);
                            URLConnection conn = url.openConnection();
                            InputStream in = conn.getInputStream();
                            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                            String str = reader.readLine();
                            Message msg = new Message();
                            msg.what = 1;
                            msg.obj = str;
                            handler.sendMessage(msg);
                            in.close();
                            reader.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });
        return convertView;
    }
}
