package net.onest.recipeprj.Recipe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import net.onest.recipeprj.Class.User;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class RecipeCommentActivity extends AppCompatActivity {
    private String recipeName;
    private EditText commentInfo;
    private Button btnComment;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] info = str.split("&&&");
                    if ("true".equals(info[0])) {
                        Toast.makeText(RecipeCommentActivity.this, info[1], Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RecipeCommentActivity.this, info[1], Toast.LENGTH_SHORT).show();
                    }
                    break;
                case 2:
                    Toast.makeText(RecipeCommentActivity.this, "评论不能为空", Toast.LENGTH_SHORT).show();
                    break;
                case 3:
                    Toast.makeText(RecipeCommentActivity.this, "不能带有&符号，请用其他字符代替", Toast.LENGTH_SHORT).show();
                    break;
                case 4:
                    Toast.makeText(RecipeCommentActivity.this, "您没有权限设置此评论", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipecomment);
        commentInfo = findViewById(R.id.client_comment);
        btnComment = findViewById(R.id.btn_comment);
        Intent intent = getIntent();
        recipeName = intent.getStringExtra("recipeName");

        btnComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        try {
                            if (commentInfo.length() > 0) {
                                if (!commentInfo.getText().toString().contains("&")) {
                                    if (!"系统默认好评".equals(commentInfo.getText().toString())) {
                                        URL url = new URL(ConfigUtil.SERVER_ADDR + "comment?commentRecipe=" + recipeName + "&commentUser=" + User.getUserNumberLogin() + "&commentInfo=" + commentInfo.getText().toString());
                                        URLConnection conn = url.openConnection();
                                        InputStream in = conn.getInputStream();
                                        BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                                        String str = reader.readLine();
                                        Message msg = new Message();
                                        msg.what = 1;
                                        msg.obj = str;
                                        handler.sendMessage(msg);
                                        in.close();
                                        reader.close();
                                    } else {
                                        Message msg = new Message();
                                        msg.what = 4;
                                        handler.sendMessage(msg);
                                    }
                                } else {
                                    Message msg = new Message();
                                    msg.what = 3;
                                    handler.sendMessage(msg);
                                }
                            } else {
                                Message msg = new Message();
                                msg.what = 2;
                                handler.sendMessage(msg);
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });
    }
}
