package net.onest.recipeprj.Class;

public class Recipe {
    private String recipeName;   // 菜谱名称
    private String reciptType;   // 菜谱类型
    private String recipePhotoPath;  // 存放菜谱图片路径
    private String recipeMaterial;   // 菜谱原材料
    private String recipeSteps;  // 菜谱步骤
    private int recipeLikeNum;   // 菜谱点赞数量


    public Recipe() {

    }

    public Recipe(String recipeName, String reciptType, String recipePhotoPath, String recipeMaterial,
                  String recipeSteps, int recipeLikeNum) {
        super();
        this.recipeName = recipeName;
        this.reciptType = reciptType;
        this.recipePhotoPath = recipePhotoPath;
        this.recipeMaterial = recipeMaterial;
        this.recipeSteps = recipeSteps;
        this.recipeLikeNum = recipeLikeNum;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public String getReciptType() {
        return reciptType;
    }

    public void setReciptType(String reciptType) {
        this.reciptType = reciptType;
    }

    public String getRecipePhotoPath() {
        return recipePhotoPath;
    }

    public void setRecipePhotoPath(String recipePhotoPath) {
        this.recipePhotoPath = recipePhotoPath;
    }

    public String getRecipeMaterial() {
        return recipeMaterial;
    }

    public void setRecipeMaterial(String recipeMaterial) {
        this.recipeMaterial = recipeMaterial;
    }

    public String getRecipeSteps() {
        return recipeSteps;
    }

    public void setRecipeSteps(String recipeSteps) {
        this.recipeSteps = recipeSteps;
    }

    public int getRecipeLikeNum() {
        return recipeLikeNum;
    }

    public void setRecipeLikeNum(int recipeLikeNum) {
        this.recipeLikeNum = recipeLikeNum;
    }
}
