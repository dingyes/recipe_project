package net.onest.recipeprj.Class;

public class Comment {
    private String commentRecipe;  // 评论的菜谱名称
    private String commentNumber;  // 评论的用户号码
    private String commentInfo;    // 评论的详情

    public Comment() {

    }

    public Comment(String commentRecipe, String commentNumber, String commentInfo) {
        super();
        this.commentRecipe = commentRecipe;
        this.commentNumber = commentNumber;
        this.commentInfo = commentInfo;
    }

    public String getCommentRecipe() {
        return commentRecipe;
    }

    public void setCommentRecipe(String commentRecipe) {
        this.commentRecipe = commentRecipe;
    }

    public String getCommentNumber() {
        return commentNumber;
    }

    public void setCommentNumber(String commentNumber) {
        this.commentNumber = commentNumber;
    }

    public String getCommentInfo() {
        return commentInfo;
    }

    public void setCommentInfo(String commentInfo) {
        this.commentInfo = commentInfo;
    }
}
