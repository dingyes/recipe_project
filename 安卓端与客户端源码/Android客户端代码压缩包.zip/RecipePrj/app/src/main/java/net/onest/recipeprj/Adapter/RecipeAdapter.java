package net.onest.recipeprj.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import net.onest.recipeprj.Class.Recipe;
import net.onest.recipeprj.R;

import java.util.ArrayList;
import java.util.List;

public class RecipeAdapter extends BaseAdapter {
    private Context recipeContext;
    private List<Recipe> recipes = new ArrayList<>();
    private int itemLayoutRes;

    public RecipeAdapter(Context recipeContext, List<Recipe> recipes, int itemLayoutRes) {
        this.recipeContext = recipeContext;
        this.recipes = recipes;
        this.itemLayoutRes = itemLayoutRes;
    }

    @Override
    public int getCount() {
        if (null != recipes) {
            return recipes.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (null != recipes) {
            return recipes.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(recipeContext);
        convertView = inflater.inflate(itemLayoutRes, null);
        TextView recipe = convertView.findViewById(R.id.recipe_name);
        TextView type = convertView.findViewById(R.id.recipe_type);
        TextView number = convertView.findViewById(R.id.recipe_number);
        recipe.setText(recipes.get(position).getRecipeName());
        type.setText(recipes.get(position).getReciptType());
        number.setText(recipes.get(position).getRecipeLikeNum() + "");
        return convertView;
    }
}