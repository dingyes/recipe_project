package net.onest.recipeprj.Mine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class LoginActivity extends AppCompatActivity {
    private final int LOGIN_REQUEST = 200;
    private EditText loginPhone;
    private EditText loginPassword;
    private Button btnLogin;
    private TextView register;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    if (str.equals("true")) {
                        Intent intent = new Intent(LoginActivity.this, MineFragment.class);
                        intent.putExtra("phone", loginPhone.getText().toString());
                        setResult(LOGIN_REQUEST, intent);
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "您输入的信息有误", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViews();
        setListeners();
    }

    /**
     * 获取布局文件中的控件对象
     */
    private void findViews() {
        loginPhone = findViewById(R.id.login_phone);
        loginPassword = findViewById(R.id.login_password);
        btnLogin = findViewById(R.id.btn_login);
        register = findViewById(R.id.register);
    }

    /**
     * 注册监听器
     */
    private void setListeners() {
        MyClickListener listener = new MyClickListener();
        btnLogin.setOnClickListener(listener);
        register.setOnClickListener(listener);
    }

    /**
     * 内部类方式自定义点击事件监听器
     */
    private class MyClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_login:
                    loginVerification();
                    break;
                case R.id.register:
                    Intent intent1 = new Intent();
                    intent1.setClass(LoginActivity.this, RegisterActivity.class);
                    startActivity(intent1);
                    break;
            }
        }
    }

    private void loginVerification() {
        if (loginPhone.length() == 11) {
            if (loginPassword.length() > 0) {
                new Thread() {
                    @Override
                    public void run() {
                        try {
                            String phone = loginPhone.getText().toString();
                            String password = loginPassword.getText().toString();
                            String userValue = "?phone=" + phone + "&password=" + password;
                            // 获取url对象
                            URL url = new URL(ConfigUtil.SERVER_ADDR + "login" + userValue);
                            // 获取URLConnection
                            URLConnection conn = url.openConnection();
                            // 获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));
                            //读取字符信息
                            String str = reader.readLine();
                            Message msg = new Message();
                            msg.obj = str;
                            msg.what = 1;
                            handler.sendMessage(msg);
                            in.close();
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            } else {
                Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "手机号码格式不对，应为11位数字", Toast.LENGTH_SHORT).show();
        }
    }

}