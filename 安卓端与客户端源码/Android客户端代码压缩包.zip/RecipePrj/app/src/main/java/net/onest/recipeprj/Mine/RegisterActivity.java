package net.onest.recipeprj.Mine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class RegisterActivity extends AppCompatActivity {
    private EditText registerPhone;
    private EditText registerPassword;
    private RadioGroup group;
    private EditText registerName;
    private RadioButton male;
    private RadioButton female;
    private Button btnRegister;
    private String sex = "男";
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] message = str.split("&&&");
                    if (message[0].equals("true")) {
                        Toast.makeText(RegisterActivity.this, message[1], Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RegisterActivity.this, message[1], Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        registerPhone = findViewById(R.id.register_phone);
        registerPassword = findViewById(R.id.register_password);
        group = findViewById(R.id.group);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        btnRegister = findViewById(R.id.btn_registe);
        registerName = findViewById(R.id.register_name);

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // 选中单选按钮
                switch (checkedId) {
                    case R.id.male:
                        male.setChecked(true);
                        female.setChecked(false);
                        sex = "男";
                        break;
                    case R.id.female:
                        male.setChecked(false);
                        female.setChecked(true);
                        sex = "女";
                        break;
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (registerPhone.length() == 11) {
                    if (registerPassword.length() > 0) {
                        if (registerName.length() > 0) {
                            upRegisterValue(ConfigUtil.SERVER_ADDR + "register");
                        } else {
                            Toast.makeText(RegisterActivity.this, "请输入昵称", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(RegisterActivity.this, "请输入密码", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(RegisterActivity.this, "手机号码格式不对，应为11位数字", Toast.LENGTH_SHORT).show();
                }
            }

            private void upRegisterValue(final String s) {
                new Thread() {
                    @Override
                    public void run() {
                        String phone = registerPhone.getText().toString();
                        String password = registerPassword.getText().toString();
                        String name = registerName.getText().toString();
                        String registerValue = "?phone=" + phone + "&password=" + password + "&name=" + name + "&sex=" + sex;
                        try {
                            URL url = new URL(s + registerValue);
                            // 获取URLConnection
                            URLConnection conn = url.openConnection();
                            // 获取网络输入流
                            InputStream in = conn.getInputStream();
                            //使用字符流读取
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in, "utf-8"));
                            //读取字符信息
                            String str = reader.readLine();
                            Message msg = new Message();
                            msg.obj = str;
                            msg.what = 1;
                            handler.sendMessage(msg);
                            in.close();
                            reader.close();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });
    }
}
