package net.onest.recipeprj.Mine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class UpdateImgActivity extends AppCompatActivity {
    private final int UPDATE_REQUEST = 400;
    private ImageView iv1;
    private ImageView iv2;
    private ImageView iv3;
    private ImageView iv4;
    private ImageView iv5;
    private ImageView iv6;
    private ImageView iv7;
    private ImageView iv8;
    private ImageView iv9;
    private ImageView iv10;
    private String phone;
    private Handler handler = new Handler() {

        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String flag = (String) msg.obj;
                    if ("true".equals(flag)) {
                        Toast.makeText(UpdateImgActivity.this, "修改成功", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UpdateImgActivity.this, MineFragment.class);
                        intent.putExtra("phone", phone);
                        setResult(UPDATE_REQUEST, intent);
                        finish();
                    } else {
                        Toast.makeText(UpdateImgActivity.this, "修改失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updateimg);
        Intent intent = getIntent();
        phone = intent.getStringExtra("phone");
        //获取控件
        getViews();
        setListeners();
    }

    //获取控件
    private void getViews() {
        //图片控件集合的初始化
        iv1 = findViewById(R.id.iv1);
        iv2 = findViewById(R.id.iv2);
        iv3 = findViewById(R.id.iv3);
        iv4 = findViewById(R.id.iv4);
        iv5 = findViewById(R.id.iv5);
        iv6 = findViewById(R.id.iv6);
        iv7 = findViewById(R.id.iv7);
        iv8 = findViewById(R.id.iv8);
        iv9 = findViewById(R.id.iv9);
        iv10 = findViewById(R.id.iv10);
    }

    private void setListeners() {
        UpdateImgActivity.MyClickListener listener = new UpdateImgActivity.MyClickListener();
        iv1.setOnClickListener(listener);
        iv2.setOnClickListener(listener);
        iv3.setOnClickListener(listener);
        iv4.setOnClickListener(listener);
        iv5.setOnClickListener(listener);
        iv6.setOnClickListener(listener);
        iv7.setOnClickListener(listener);
        iv8.setOnClickListener(listener);
        iv9.setOnClickListener(listener);
        iv10.setOnClickListener(listener);
    }

    /**
     * 内部类方式自定义点击事件监听器
     */
    private class MyClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.iv1:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img1.jpg");
                    break;
                case R.id.iv2:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img2.jpg");
                    break;
                case R.id.iv3:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img3.jpg");
                    break;
                case R.id.iv4:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img4.jpg");
                    break;
                case R.id.iv5:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img5.jpg");
                    break;
                case R.id.iv6:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img6.jpg");
                    break;
                case R.id.iv7:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img7.jpg");
                    break;
                case R.id.iv8:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img8.jpg");
                    break;
                case R.id.iv9:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img9.jpg");
                    break;
                case R.id.iv10:
                    updateImg(ConfigUtil.SERVER_ADDR + "updateImg?phone=" + phone + "&path=images\\\\userImgs\\\\img10.jpg");
                    break;
            }
        }
    }

    private void updateImg(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
