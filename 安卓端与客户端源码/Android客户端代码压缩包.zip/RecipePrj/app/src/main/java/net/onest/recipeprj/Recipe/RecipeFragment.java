package net.onest.recipeprj.Recipe;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import net.onest.recipeprj.Adapter.RecipeAdapter;
import net.onest.recipeprj.Class.Recipe;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class RecipeFragment extends Fragment {
    private ListView recipeListView;
    private View root;
    private RecipeAdapter recipeAdapter;
    private List<Recipe> recipes = new ArrayList<>();
    private TextView lu;
    private TextView chuan;
    private TextView su;
    private TextView yue;
    private TextView min;
    private TextView zhe;
    private TextView xiang;
    private TextView hui;
    private EditText research;
    private Button btnResearch;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] recipeInfos = str.split("&&&");
                    if (recipeInfos.length == 0 || "false".equals(recipeInfos[0])) {
                        Toast.makeText(getContext(), "暂无菜谱", Toast.LENGTH_SHORT).show();
                    } else {
                        for (int i = 1; i < recipeInfos.length; i++) {
                            String[] recipeInfo = recipeInfos[i].split("&");
                            Recipe recipe = new Recipe();
                            recipe.setRecipeName(recipeInfo[0]);
                            recipe.setReciptType(recipeInfo[1]);
                            if (null != recipeInfo[2]) {
                                int recipeNum = Integer.parseInt(recipeInfo[2]);
                                recipe.setRecipeLikeNum(recipeNum);
                            }
                            recipes.add(recipe);
                        }
                    }
                    // 创建Adapter并绑定
                    recipeAdapter = new RecipeAdapter(getContext(), recipes, R.layout.recipe_list_item);
                    recipeListView = root.findViewById(R.id.recipe);
                    recipeListView.setAdapter(recipeAdapter);
                    recipeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Intent intent = new Intent();
                            intent.setClass(getContext(), RecipeActivity.class);
                            intent.putExtra("recipeName", recipes.get(position).getRecipeName());
                            startActivity(intent);
                        }
                    });
                    break;
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_recipe, container, false);
        getViews();
        setListeners();
        if (null == recipeListView) {
            getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes");
        }
        return root;
    }

    private void getViews() {
        lu = root.findViewById(R.id.lu);
        chuan = root.findViewById(R.id.chuan);
        yue = root.findViewById(R.id.yue);
        su = root.findViewById(R.id.su);
        min = root.findViewById(R.id.min);
        zhe = root.findViewById(R.id.zhe);
        xiang = root.findViewById(R.id.xiang);
        hui = root.findViewById(R.id.hui);
        research = root.findViewById(R.id.research);
        btnResearch = root.findViewById(R.id.btn_research);
    }

    private void setListeners() {
        RecipeFragment.MyClickListener listener = new RecipeFragment.MyClickListener();
        lu.setOnClickListener(listener);
        chuan.setOnClickListener(listener);
        yue.setOnClickListener(listener);
        su.setOnClickListener(listener);
        min.setOnClickListener(listener);
        zhe.setOnClickListener(listener);
        xiang.setOnClickListener(listener);
        hui.setOnClickListener(listener);
        btnResearch.setOnClickListener(listener);
    }

    /**
     * 内部类方式自定义点击事件监听器
     */
    private class MyClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.lu:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=鲁菜");
                    break;
                case R.id.chuan:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=川菜");
                    break;
                case R.id.su:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=苏菜");
                    break;
                case R.id.yue:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=粤菜");
                    break;
                case R.id.min:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=闽菜");
                    break;
                case R.id.zhe:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=浙菜");
                    break;
                case R.id.xiang:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=湘菜");
                    break;
                case R.id.hui:
                    if (research.length() > 0) {
                        research.setText("");
                    }
                    getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes?type=徽菜");
                    break;
                case R.id.btn_research:
                    if (research.length() > 0) {
                        getSearchResult(ConfigUtil.SERVER_ADDR + "searchRecipe?information=" + research.getText().toString());
                    } else {
                        Toast.makeText(getContext(), "请输入文字", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    }

    private void getSearchResult(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    recipes.clear();
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void getRecipeInfo(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    recipes.clear();
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (null != recipeListView) {
            if (research.length() > 0) {
                research.setText("");
            }
            getRecipeInfo(ConfigUtil.SERVER_ADDR + "recipes");
        }
    }
}
