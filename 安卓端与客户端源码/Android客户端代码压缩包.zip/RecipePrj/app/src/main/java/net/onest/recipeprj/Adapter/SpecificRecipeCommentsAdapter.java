package net.onest.recipeprj.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import net.onest.recipeprj.Class.Comment;
import net.onest.recipeprj.R;

import java.util.ArrayList;
import java.util.List;

public class SpecificRecipeCommentsAdapter extends BaseAdapter {
    private Context commentContext;
    private List<Comment> comments = new ArrayList<>();
    private int itemLayoutRes;

    public SpecificRecipeCommentsAdapter(Context commentContext, List<Comment> comments, int itemLayoutRes) {
        this.commentContext = commentContext;
        this.comments = comments;
        this.itemLayoutRes = itemLayoutRes;
    }

    @Override
    public int getCount() {
        if (null != comments) {
            return comments.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (null != comments) {
            return comments.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(commentContext);
        convertView = inflater.inflate(itemLayoutRes, null);
        // 获取控件引用
        TextView commentUser = convertView.findViewById(R.id.recipe_comment_user);
        TextView commentInfo = convertView.findViewById(R.id.recipe_comment_info);

        commentUser.setText(comments.get(position).getCommentNumber());
        commentInfo.setText(comments.get(position).getCommentInfo());
        return convertView;
    }
}
