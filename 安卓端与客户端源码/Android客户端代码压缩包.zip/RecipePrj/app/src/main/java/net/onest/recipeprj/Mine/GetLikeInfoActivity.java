package net.onest.recipeprj.Mine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ListView;
import android.widget.Toast;

import net.onest.recipeprj.Adapter.LikeInfoAdapter;
import net.onest.recipeprj.Class.LikeInfo;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class GetLikeInfoActivity extends AppCompatActivity {
    private LikeInfoAdapter likeInfoAdapter;
    private List<LikeInfo> likeInfos = new ArrayList<>();
    private String phone;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] recipes = str.split("&&&");
                    if (recipes.length == 0) {
                        Toast.makeText(GetLikeInfoActivity.this, "您还没有点赞，快去菜谱详情页点赞吧", Toast.LENGTH_SHORT).show();
                    } else {
                        for (int i = 1; i < recipes.length; i++) {
                            LikeInfo likeInfo = new LikeInfo(recipes[i], phone);
                            likeInfos.add(likeInfo);
                        }
                    }
                    // 创建Adapter并绑定
                    likeInfoAdapter = new LikeInfoAdapter(GetLikeInfoActivity.this, likeInfos, R.layout.likeinfo_list_item);
                    ListView likeListView = findViewById(R.id.likeinfo);
                    likeListView.setAdapter(likeInfoAdapter);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getlikeinfo);
        // 获取传入的数据
        Intent request = getIntent();
        phone = request.getStringExtra("phone");
        // 准备数据
        getLikeInfos(ConfigUtil.SERVER_ADDR + "getLikeinfo?phone=" + phone);
    }

    private void getLikeInfos(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }
}
