package net.onest.recipeprj.Recipe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import net.onest.recipeprj.Adapter.SpecificRecipeCommentsAdapter;
import net.onest.recipeprj.Class.Comment;
import net.onest.recipeprj.Class.User;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;


public class RecipeActivity extends AppCompatActivity {
    private String name;
    private ImageView recipeImg;
    private TextView recipeLikeNum;
    private TextView recipeName;
    private TextView recipeType;
    private TextView recipeMaterial;
    private TextView recipeSteps;
    private TextView recipeComment;
    private TextView recipeLike;
    private SpecificRecipeCommentsAdapter crecipeCmmentAdapter;
    private List<Comment> recipeComments = new ArrayList<>();
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] recipeInfo = str.split("&&&");
                    recipeName.setText(name);
                    recipeType.setText(recipeInfo[0]);
                    recipeMaterial.setText(recipeInfo[1]);
                    recipeSteps.setText(recipeInfo[2]);
                    recipeLikeNum.setText(recipeInfo[3]);
                    break;
                case 2:
                    String str2 = (String) msg.obj;
                    String[] like = str2.split("&&&");
                    if ("true".equals(like[0])) {
                        Toast.makeText(RecipeActivity.this, like[1], Toast.LENGTH_SHORT).show();
                        int number = Integer.parseInt(recipeLikeNum.getText().toString()) + 1;
                        recipeLikeNum.setText(number + "");
                    } else {
                        Toast.makeText(RecipeActivity.this, like[1], Toast.LENGTH_SHORT).show();
                    }
                    break;
                case 3:
                    String string = (String) msg.obj;
                    Toast.makeText(RecipeActivity.this, string, Toast.LENGTH_SHORT).show();
                    break;
                case 4:
                    Bitmap rawBitmap = (Bitmap) msg.obj;
                    //把图片显示在图片控件中
                    Bitmap bitmap = ConfigUtil.zoomBitmap(rawBitmap, 95, 90);
                    recipeImg.setImageBitmap(bitmap);
                    break;
                case 5:
                    String strings = (String) msg.obj;
                    String[] infos = strings.split("&&&");
                    for (int i = 1; i < infos.length; i++) {
                        String[] comInfo = infos[i].split("&");
                        if (comInfo.length == 1) {
                            Comment comment = new Comment(name, comInfo[0], "系统默认好评");
                            recipeComments.add(comment);
                        } else {
                            Comment comment = new Comment(name, comInfo[0], comInfo[1]);
                            recipeComments.add(comment);
                        }
                    }
                    // 创建Adapter并绑定
                    crecipeCmmentAdapter = new SpecificRecipeCommentsAdapter(RecipeActivity.this, recipeComments, R.layout.recipecomment_list_item);
                    ListView likeListView = findViewById(R.id.recipe_comments);
                    likeListView.setAdapter(crecipeCmmentAdapter);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        Intent intent = getIntent();
        name = intent.getStringExtra("recipeName");
        getViews();
        initData(ConfigUtil.SERVER_ADDR + "recipe?recipeName=" + name);
        initRecipeImg(ConfigUtil.SERVER_ADDR + "recipeImg?recipeName=" + name);
        initRecipeComment(ConfigUtil.SERVER_ADDR + "recipeComment?recipeName=" + name);
        recipeLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    @Override
                    public void run() {
                        try {
                            if (null != User.getUserNumberLogin()) {
                                URL url = new URL(ConfigUtil.SERVER_ADDR + "like?likeRecipe=" + name + "&LikeUser=" + User.getUserNumberLogin());
                                URLConnection conn = url.openConnection();
                                InputStream in = conn.getInputStream();
                                BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                                String str = reader.readLine();
                                Message msg = new Message();
                                msg.what = 2;
                                msg.obj = str;
                                handler.sendMessage(msg);
                                in.close();
                                reader.close();
                            } else {
                                Message msg = new Message();
                                msg.what = 3;
                                msg.obj = "您还未登录，请登录";
                                handler.sendMessage(msg);
                            }
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });

        recipeComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != User.getUserNumberLogin()) {
                    Intent intent1 = new Intent();
                    intent1.setClass(RecipeActivity.this, RecipeCommentActivity.class);
                    intent1.putExtra("recipeName", name);
                    startActivity(intent1);
                } else {
                    Toast.makeText(RecipeActivity.this, "您还未登录，请登录", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getViews() {
        recipeName = findViewById(R.id.recipe_name);
        recipeType = findViewById(R.id.recipe_type);
        recipeMaterial = findViewById(R.id.recipe_material);
        recipeSteps = findViewById(R.id.recipe_steps);
        recipeComment = findViewById(R.id.recipe_comment);
        recipeLike = findViewById(R.id.recipe_like);
        recipeImg = findViewById(R.id.recipe_photo);
        recipeLikeNum = findViewById(R.id.recipe_likeNum);
    }

    private void initData(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void initRecipeImg(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    //获取字节输入流
                    InputStream in = conn.getInputStream();
                    //把输入流解析成一个Bitmap对象
                    Bitmap bitmap = BitmapFactory.decodeStream(in);
                    in.close();
                    //借助于Message，将图片显示在界面上
                    Message msg = new Message();
                    msg.what = 4;
                    msg.obj = bitmap;
                    handler.sendMessage(msg);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void initRecipeComment(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 5;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}

