package net.onest.recipeprj;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTabHost;

import android.os.Bundle;
import android.widget.TabHost;

import net.onest.recipeprj.Mine.MineFragment;
import net.onest.recipeprj.Rank.RankFragment;
import net.onest.recipeprj.Recipe.RecipeFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initFragmentTabHost();
    }

    private void initFragmentTabHost() {
        FragmentTabHost tabHost = findViewById(android.R.id.tabhost);
        tabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);
        TabHost.TabSpec tab1 = tabHost.newTabSpec("tab1").setIndicator("菜谱");
        tabHost.addTab(tab1, RecipeFragment.class, null);
        TabHost.TabSpec tab2 = tabHost.newTabSpec("tab2").setIndicator("排行");
        tabHost.addTab(tab2, RankFragment.class, null);
        TabHost.TabSpec tab3 = tabHost.newTabSpec("tab3").setIndicator("我的");
        tabHost.addTab(tab3, MineFragment.class, null);
    }
}
