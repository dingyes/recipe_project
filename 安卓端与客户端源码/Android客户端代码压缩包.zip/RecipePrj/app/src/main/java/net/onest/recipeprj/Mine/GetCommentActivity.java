package net.onest.recipeprj.Mine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ListView;
import android.widget.Toast;

import net.onest.recipeprj.Adapter.CommentAdapter;
import net.onest.recipeprj.Class.Comment;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class GetCommentActivity extends AppCompatActivity {
    private CommentAdapter commentAdapter;
    private List<Comment> comments = new ArrayList<>();
    private String phone;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] infos = str.split("&&&");
                    if (infos.length == 0) {
                        Toast.makeText(GetCommentActivity.this, "您还没有评论，快去菜谱详情页评论吧", Toast.LENGTH_SHORT).show();
                    } else {
                        for (int i = 1; i < infos.length; i++) {
                            String[] comInfo = infos[i].split("&");
                            if (comInfo.length == 1) {
                                Comment comment = new Comment(comInfo[0], phone, "系统默认好评");
                                comments.add(comment);
                            } else {
                                Comment comment = new Comment(comInfo[0], phone, comInfo[1]);
                                comments.add(comment);
                            }
                        }
                        // 创建Adapter并绑定
                        commentAdapter = new CommentAdapter(GetCommentActivity.this, comments, R.layout.commit_list_item);
                        ListView likeListView = findViewById(R.id.comment);
                        likeListView.setAdapter(commentAdapter);
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getcomment);
        // 获取传入的数据
        Intent request = getIntent();
        phone = request.getStringExtra("phone");
        // 准备数据
        getComments(ConfigUtil.SERVER_ADDR + "getComment?phone=" + phone);
    }

    private void getComments(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
