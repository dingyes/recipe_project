package net.onest.recipeprj.Mine;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class UpdateInfoActivity extends AppCompatActivity {
    private final int UPDATE_REQUEST = 300;
    private String userNumber;
    private RadioGroup updateGroup;
    private RadioButton updateMale;
    private RadioButton updateFemale;
    private Button btnUpdate;
    private EditText updateName;
    private String hobby = "、";
    private String sex = "男";
    private CheckBox lu;
    private CheckBox chuan;
    private CheckBox yue;
    private CheckBox su;
    private CheckBox min;
    private CheckBox zhe;
    private CheckBox xiang;
    private CheckBox hui;
    private int[] flags = {0, 0, 0, 0, 0, 0, 0, 0};
    private String[] recipes = {"鲁菜、", "川菜、", "粤菜、", "苏菜、", "闽菜、", "浙菜、", "湘菜、", "徽菜、"};
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    if ("true".equals(str)) {
                        Toast.makeText(UpdateInfoActivity.this, "更新信息成功", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UpdateInfoActivity.this, MineFragment.class);
                        intent.putExtra("phone", userNumber);
                        setResult(UPDATE_REQUEST, intent);
                        finish();
                    } else {
                        Toast.makeText(UpdateInfoActivity.this, "更新信息失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_updateinfo);
        Intent intent = getIntent();
        userNumber = intent.getStringExtra("phone");
        findViews();
        String userName = intent.getStringExtra("userName");
        updateName.setText(userName);
        setClickListener();
        updateGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // 选中单选按钮
                switch (checkedId) {
                    case R.id.update_male:
                        updateMale.setChecked(true);
                        updateFemale.setChecked(false);
                        sex = "男";
                        break;
                    case R.id.update_female:
                        updateMale.setChecked(false);
                        updateFemale.setChecked(true);
                        sex = "女";
                        break;
                }
            }
        });
    }

    private void findViews() {
        updateGroup = findViewById(R.id.update_group);
        updateMale = findViewById(R.id.update_male);
        updateFemale = findViewById(R.id.update_female);
        updateName = findViewById(R.id.update_name);
        btnUpdate = findViewById(R.id.btn_update);
        lu = findViewById(R.id.lu);
        chuan = findViewById(R.id.chuan);
        yue = findViewById(R.id.yue);
        su = findViewById(R.id.su);
        min = findViewById(R.id.min);
        zhe = findViewById(R.id.zhe);
        xiang = findViewById(R.id.xiang);
        hui = findViewById(R.id.hui);
    }

    private void setClickListener() {
        UpdateInfoActivity.MyClickListener listener = new UpdateInfoActivity.MyClickListener();
        lu.setOnClickListener(listener);
        chuan.setOnClickListener(listener);
        yue.setOnClickListener(listener);
        su.setOnClickListener(listener);
        min.setOnClickListener(listener);
        zhe.setOnClickListener(listener);
        xiang.setOnClickListener(listener);
        hui.setOnClickListener(listener);
        btnUpdate.setOnClickListener(listener);
    }

    class MyClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.lu:
                    if (flags[0] == 0) {
                        flags[0] = 1;
                    } else {
                        flags[0] = 0;
                    }
                    break;
                case R.id.chuan:
                    if (flags[1] == 0) {
                        flags[1] = 1;
                    } else {
                        flags[1] = 0;
                    }
                    break;
                case R.id.yue:
                    if (flags[2] == 0) {
                        flags[2] = 1;
                    } else {
                        flags[2] = 0;
                    }
                    break;
                case R.id.su:
                    if (flags[3] == 0) {
                        flags[3] = 1;
                    } else {
                        flags[3] = 0;
                    }
                    break;
                case R.id.min:
                    if (flags[4] == 0) {
                        flags[4] = 1;
                    } else {
                        flags[4] = 0;
                    }
                    break;
                case R.id.zhe:
                    if (flags[5] == 0) {
                        flags[5] = 1;
                    } else {
                        flags[5] = 0;
                    }
                    break;
                case R.id.xiang:
                    if (flags[6] == 0) {
                        flags[6] = 1;
                    } else {
                        flags[6] = 0;
                    }
                    break;
                case R.id.hui:
                    if (flags[7] == 0) {
                        flags[7] = 1;
                    } else {
                        flags[7] = 0;
                    }
                    break;
                case R.id.btn_update:
                    if (updateName.length() > 0) {
                        for (int i = 0; i < flags.length; i++) {
                            if (flags[i] == 1) {
                                hobby = hobby + recipes[i];
                            }
                        }
                        if (!"、".equals(hobby)) {
                            updateInfoCommit(ConfigUtil.SERVER_ADDR + "update?userNumber=" + userNumber + "&updateName=" + updateName.getText().toString() + "&sex=" + sex + "&hobby=" + hobby);
                        } else {
                            Toast.makeText(UpdateInfoActivity.this, "请选择爱好", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(UpdateInfoActivity.this, "请输入名称", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        }
    }

    private void updateInfoCommit(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

}
