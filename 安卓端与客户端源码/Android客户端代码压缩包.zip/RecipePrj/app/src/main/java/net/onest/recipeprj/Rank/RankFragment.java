package net.onest.recipeprj.Rank;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import net.onest.recipeprj.Adapter.RankAdapter;
import net.onest.recipeprj.Class.Recipe;
import net.onest.recipeprj.ConfigUtil;
import net.onest.recipeprj.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class RankFragment extends Fragment {
    private View root;
    private RankAdapter rankAdapter;
    private List<Recipe> recipes = new ArrayList<>();
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what) {
                case 1:
                    String str = (String) msg.obj;
                    String[] recipeInfos = str.split("&&&");
                    for (int i = 1; i < recipeInfos.length; i++) {
                        String[] recipeInfo = recipeInfos[i].split("&");
                        Recipe recipe = new Recipe();
                        recipe.setRecipeName(recipeInfo[0]);
                        recipe.setReciptType(recipeInfo[1]);
                        if (null != recipeInfo[2]) {
                            int recipeNum = Integer.parseInt(recipeInfo[2]);
                            recipe.setRecipeLikeNum(recipeNum);
                        }
                        recipes.add(recipe);
                    }
                    // 创建Adapter并绑定
                    rankAdapter = new RankAdapter(getContext(), recipes, R.layout.rank_list_item);
                    ListView likeListView = root.findViewById(R.id.rank);
                    likeListView.setAdapter(rankAdapter);
                    break;
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_rank, container, false);
        getRankInfo(ConfigUtil.SERVER_ADDR + "rank");
        return root;
    }

    private void getRankInfo(final String s) {
        new Thread() {
            @Override
            public void run() {
                try {
                    recipes.clear();
                    URL url = new URL(s);
                    URLConnection conn = url.openConnection();
                    InputStream in = conn.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "utf-8"));
                    String str = reader.readLine();
                    Message msg = new Message();
                    msg.what = 1;
                    msg.obj = str;
                    handler.sendMessage(msg);
                    in.close();
                    reader.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
