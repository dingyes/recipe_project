package net.onest.recipeprj.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import net.onest.recipeprj.Class.LikeInfo;
import net.onest.recipeprj.R;

import java.util.ArrayList;
import java.util.List;

public class LikeInfoAdapter extends BaseAdapter {
    private Context likeContext;
    private List<LikeInfo> likeInfos = new ArrayList<>();
    private int itemLayoutRes;

    public LikeInfoAdapter(Context likeContext, List<LikeInfo> likeInfos, int itemLayoutRes) {
        this.likeContext = likeContext;
        this.likeInfos = likeInfos;
        this.itemLayoutRes = itemLayoutRes;
    }

    @Override
    public int getCount() {
        if (null != likeInfos) {
            return likeInfos.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (null != likeInfos) {
            return likeInfos.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(likeContext);
        convertView = inflater.inflate(itemLayoutRes, null);

        // 获取控件
        TextView recipe = convertView.findViewById(R.id.like_recipe);
        // 获取item中控件的引用
        recipe.setText(likeInfos.get(position).getLikeRecipe());
        return convertView;
    }
}
