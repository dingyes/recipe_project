package net.onest.recipeprj.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import net.onest.recipeprj.Class.Recipe;
import net.onest.recipeprj.R;

import java.util.ArrayList;
import java.util.List;

public class RankAdapter extends BaseAdapter {
    private Context rankContext;
    private List<Recipe> ranks = new ArrayList<>();
    private int itemLayoutRes;

    public RankAdapter(Context rankContext, List<Recipe> ranks, int itemLayoutRes) {
        this.rankContext = rankContext;
        this.ranks = ranks;
        this.itemLayoutRes = itemLayoutRes;
    }

    @Override
    public int getCount() {
        if (null != ranks) {
            return ranks.size();
        }
        return 0;
    }

    @Override
    public Object getItem(int position) {
        if (null != ranks) {
            return ranks.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(rankContext);
        convertView = inflater.inflate(itemLayoutRes, null);

        TextView recipe = convertView.findViewById(R.id.rank_recipe);
        TextView type = convertView.findViewById(R.id.rank_type);
        TextView number = convertView.findViewById(R.id.rank_number);

        recipe.setText(ranks.get(position).getRecipeName());
        type.setText(ranks.get(position).getReciptType());
        number.setText(ranks.get(position).getRecipeLikeNum() + "");
        return convertView;
    }
}
