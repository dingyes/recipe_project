package net.onest.recipeprj.Class;

public class User {
    private static String userNumberLogin = null;
    private String userNumber;   // 存放用户电话号码
    private String userName;     // 用户姓名
    private String userPassword; // 用户登录密码
    private String userSex;      // 用户性别
    private String userPhoto;    // 存放用户图片路径
    private String userHobby;    // 用户爱好

    public User() {

    }

    public static String getUserNumberLogin() {
        return userNumberLogin;
    }

    public static void setUserNumberLogin(String userNumberLogin) {
        User.userNumberLogin = userNumberLogin;
    }

    public String getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(String userNumber) {
        this.userNumber = userNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserSex() {
        return userSex;
    }

    public void setUserSex(String userSex) {
        this.userSex = userSex;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto;
    }

    public String getUserHobby() {
        return userHobby;
    }

    public void setUserHobby(String userHobby) {
        this.userHobby = userHobby;
    }
}
